// IMPORTANT: Replace this placeholder with your WhatsApp number in international format.
// India example: 919876543210 (country code 91, no +, spaces or leading zero).
const WHATSAPP_NUMBER = "91XXXXXXXXXX";

document.getElementById("year").textContent = new Date().getFullYear();

const menuButton = document.querySelector(".menu-toggle");
const nav = document.querySelector(".nav");
menuButton.addEventListener("click", () => {
  const open = nav.classList.toggle("open");
  menuButton.setAttribute("aria-expanded", String(open));
});
nav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
  nav.classList.remove("open");
  menuButton.setAttribute("aria-expanded", "false");
}));

document.querySelectorAll(".whatsapp-link").forEach(link => {
  link.addEventListener("click", event => {
    if (link.getAttribute("href") !== "#contact") return;
    if (WHATSAPP_NUMBER.includes("X")) {
      event.preventDefault();
      alert("Please add your WhatsApp number in script.js before publishing.");
    }
  });
});

document.getElementById("enquiry-form").addEventListener("submit", event => {
  event.preventDefault();
  if (WHATSAPP_NUMBER.includes("X")) {
    alert("Please add your WhatsApp number in script.js before publishing.");
    return;
  }
  const data = new FormData(event.currentTarget);
  const message = [
    "Hello IM Digital Solutions,",
    "Name: " + data.get("name"),
    "Phone: " + data.get("phone"),
    "Service: " + data.get("service"),
    "Project details: " + (data.get("details") || "Not provided")
  ].join("\\n");
  window.open("https://wa.me/" + WHATSAPP_NUMBER + "?text=" + encodeURIComponent(message), "_blank", "noopener");
});
