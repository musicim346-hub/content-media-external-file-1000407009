IM DIGITAL SOLUTIONS WEBSITE
=============================

FILES
- index.html: website content
- style.css: responsive styling
- script.js: mobile menu and WhatsApp enquiry form

BEFORE PUBLISHING
1. Open script.js in a text editor.
2. Replace 91XXXXXXXXXX with your WhatsApp number in international format.
   India example: 919876543210 (no +, spaces or leading zero).
3. Review all package prices and service descriptions. They are sample starting prices.
4. Add your real business email/address if you want those displayed.
5. Test the website on your phone.

FREE PUBLISHING WITH GITHUB PAGES
1. Sign in at https://github.com/
2. Create a new public repository named im-digital-solutions
3. Upload index.html, style.css and script.js to the repository root.
4. Open repository Settings -> Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select branch main and folder /(root), then Save.
7. Wait for GitHub Pages to publish. Your address will look like:
   https://YOUR-GITHUB-USERNAME.github.io/im-digital-solutions/

NOTES
- GitHub Pages hosts static websites for free. This contact form opens WhatsApp;
  it does not save enquiries to a database.
- A custom domain, business email, WordPress, customer login areas, server-side
  applications and paid hosting are separate services/costs.
- Do not promise hosting capacity or uptime beyond the provider's published terms.
- Keep a backup of your website files.
